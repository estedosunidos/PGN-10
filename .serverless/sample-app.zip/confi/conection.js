const mysql1={db:{
    host:'database-1.c8gwgfuyxbba.us-east-1.rds.amazonaws.com',
    database:'pgn',
    port:'3306',
    user:'root',
    password:'miniTa123'
}}
module.exports=mysql1