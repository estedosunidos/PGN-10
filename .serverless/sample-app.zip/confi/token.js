const configuracion={
    TOKEN_SECRET: process.env.TOKEN_SECRET || "hola"

}
module.exports=configuracion